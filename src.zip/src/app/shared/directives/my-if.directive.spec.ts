import { MyIfDirective } from './my-if.directive';

describe('MyIfDirective', () => {
  it('should create an instance', () => {
    const directive = new MyIfDirective();
    expect(directive).toBeTruthy();
  });
});
