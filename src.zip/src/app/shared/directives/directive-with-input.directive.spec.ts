import { DirectiveWithInputDirective } from './directive-with-input.directive';

describe('DirectiveWithInputDirective', () => {
  it('should create an instance', () => {
    const directive = new DirectiveWithInputDirective();
    expect(directive).toBeTruthy();
  });
});
