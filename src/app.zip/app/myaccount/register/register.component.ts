import { Component, OnInit } from '@angular/core';
import { FormControl,NgForm } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  form: any;
    name = "miny";
    
  constructor() { }

  ngOnInit() {
  }

  submit(){
      console.log(this.form);
  }

}
